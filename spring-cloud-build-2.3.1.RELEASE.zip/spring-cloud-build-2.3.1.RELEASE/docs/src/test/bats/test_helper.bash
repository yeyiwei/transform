#!/bin/bash

FIXTURES_DIR="${BATS_TEST_DIRNAME}/fixtures"
SOURCE_DIR="${BATS_TEST_DIRNAME}/../../main/asciidoc"

export FIXTURES_DIR SOURCE_DIR
